using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class SkillButtonWithDelay : MonoBehaviour
{
    public Button skillButton;
    public float delayTime = 0.1f;

    void Start()
    {
        // Attach the skill button click event to the DelayedUseSkill function
        skillButton.onClick.AddListener(DelayedUseSkill);
    }

    void DelayedUseSkill()
    {
        if (!isCooldown)
        {
            StartCoroutine(ActivateSkillWithDelay());
        }
    }

    void UseSkill()
    {
        // Implement your skill's action here
        Debug.Log("Skill used!");
    }
}
